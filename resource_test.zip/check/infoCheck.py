import os
from time import sleep

from common.COM_path import path_resource
from common.my_log import mylog
from date.Chapters_data import MyData


class Check():

    def __init__(self):
        self.bookid = None
        self.chapterid = None
        self.bookchapter = None
        self.downloadbook_sign = False
        self.story_cfg_chapter_dir = {}
        self.story_select_dir = {}
        self.role_fashion_dir = {}
        self.bg_check_list = []
        self.bgm_check_list = []
        self.face_check_dir={}
        self.role_check_dir = {}
        self.role_resources_dir = {}
        self.bg_resources_list = []
        self.bgm_resources_list = []
        self.face_resources_list =[]
        self.error_dir = {}

    def initialize(self):
        self.bookid = None
        self.chapterid = None
        self.bookchapter = None
        self.downloadbook_sign = False
        self.story_cfg_chapter_dir = {}
        self.story_select_dir = {}
        self.role_fashion_dir = {}
        self.bg_check_list = []
        self.bgm_check_list = []
        self.role_check_dir = {}
        self.role_resources_dir = {}
        self.bg_resources_list = []
        self.bgm_resources_list = []

    def read_story_cfg_chapter(self, bookid, chapter_id):
        """读取当前章节信息txt"""
        bookpath = bookid + "\\data_s\\" + chapter_id + "_chat.txt"
        selectpath = bookid + "\\data_s\\" + chapter_id + "_select.txt"
        print(bookpath)
        print(selectpath)
        path = os.path.join(path_resource, bookpath)
        path1 = os.path.join(path_resource, selectpath)
        with open(path, "r", encoding='utf-8') as f:  # 设置文件对象
            data = f.read()  # 可以是随便对文件的操作
            # print(data)
        data = eval(data)
        self.story_cfg_chapter_dir[chapter_id] = data
        with open(path1, "r", encoding='utf-8') as f:  # 设置文件对象
            selectdata = f.read()  # 可以是随便对文件的操作
        self.story_select_dir[chapter_id] = eval(selectdata)
        return self.story_cfg_chapter_dir[chapter_id]

    def check(self):
        """单章检测流程"""
        MyData.download_bookresource(self.bookid)  # 拉取全书对白配置
        self.read_story_cfg_chapter(self.bookid, self.bookchapter)  # 存储章节对白配置
        chats_info = self.story_cfg_chapter_dir[self.bookchapter]  # 当前阅读章节信息
        self.add_check_info(chats_info)  # 生成需要检测的信息
        MyData.download_bookresource(self.bookchapter)  # 拉取章节资源
        self.getfile_name()  # 获取资源文件用于对比
        self.contrast()  # 对比并给出结果

    def contrast(self):
        """对比"""
        for role_id, idlist in self.role_check_dir.items():
            self.error_dir[self.bookchapter][role_id] = []
            for i in idlist:
                i = i + ".png"
                if i in self.role_resources_dir[role_id]:
                    print(role_id + "的" + i + "是ok的")
                else:
                    content ="【角色资源异常】：角色包{0}中未发现{1} 资源".format(role_id,i)
                    mylog.error(content)
                    print(role_id)
                    self.error_dir[self.bookchapter][role_id].append(content)

        for role_id, idlist in self.face_check_dir.items():
            print("role_id",role_id)
            print("idlist",idlist)
            for i in idlist:
                print("表情",i)
                if role_id not in self.role_resources_dir:
                    content ="【face资源文件夹异常】:资源包未找到{}的文件夹".format(role_id)
                    MyData.error_dir[role_id]=content
                    mylog.error(content)
                else:
                    if i in self.role_resources_dir[role_id]:
                        print(role_id + "的" + i + "是ok的")
                    else:
                        content ="【face资源异常】：角色包{0}中未发现{1} 资源".format(role_id,i)
                        mylog.error(content)
                        print(role_id)
                        self.error_dir[self.bookchapter][role_id].append(content)

            # self.error_dir[self.bookchapter][role_id] = []
            # for i in idlist:
            #     i = i + ".png"
            #     if i in self.role_resources_dir[role_id]:
            #         print(role_id + "的" + i + "是ok的")
            #     else:
            #         content ="【角色资源异常】：角色包{0}中未发现{1} 资源".format(role_id,i)
            #         mylog.error(content)
            #         print(role_id)
            #         self.error_dir[self.bookchapter][role_id].append(content)

        for bg in self.bg_check_list:
            self.error_dir[self.bookchapter]["Bg"]=[]
            if bg in self.bg_resources_list:
                print(bg + "是ok的")
            else:
                content = "【背景资源异常】：{0}资源丢失".format(bg)
                mylog.error(content)
                self.error_dir[self.bookchapter]["Bg"].append(content)
        for bgm in self.bgm_check_list:
            self.error_dir[self.bookchapter]["Bgm"]=[]
            if bgm in self.bgm_resources_list:
                print(bgm + "是ok的")
            else:
                content = "【音乐资源异常】：{0}资源丢失".format(bgm)
                mylog.error(content)
                self.error_dir[self.bookchapter]["Bgm"].append(content)




    def add_check_info(self, chats_info):
        """添加检测信息"""
        for chat in chats_info.values():
            self.add_role_id(chat)
            self.add_friend_id(chat)
            self.add_face_id(chat)
            self.add_bg_id(chat)
            self.add_bgm_id(chat)
        self.de_weight()
        self.get_roleFashionFilename()

    def de_weight(self):
        """去重"""
        self.bgm_check_list = set(self.bgm_check_list)
        self.bg_check_list = set(self.bg_check_list)
        # self.face_check_list = list(set(self.face_check_list))

        for i in self.role_fashion_dir:
            self.role_fashion_dir[i] = list(set(self.role_fashion_dir[i]))
        print("bgm_check_list", self.bgm_check_list)
        print("bg_check_list", self.bg_check_list)

        for i in self.face_check_dir:
            self.face_check_dir[i] = list(set(self.face_check_dir[i]))
        print("bgm_check_list", self.bgm_check_list)
        print("bg_check_list", self.bg_check_list)
        print("face_check_dir", self.face_check_dir)

    def get_roleFashionFilename(self):
        """获取路径，注意没有加png"""
        print("role_fashion_dir", self.role_fashion_dir)
        for role_id, role_list in self.role_fashion_dir.items():
            self.role_check_dir[role_id] = []
            Defaultlist = MyData.getDefaultFashion(self.bookid, role_id)
            self.role_check_dir[role_id] = Defaultlist
            for fashion_id in role_list:
                fashionlist = MyData.getDIYFashion(fashion_id)
                for filename in fashionlist:
                    self.role_check_dir[role_id].append(filename)

    def add_bg_id(self, chat):
        bg_id = str(chat["scene_bg_id"])
        if bg_id and bg_id != "0":
            bg_id = bg_id + ".jpg"
            self.bg_check_list.append(bg_id)

    def add_bgm_id(self, chat):
        bgm_id = str(chat["bgm_id"])
        if bgm_id and bgm_id != "0":
            bgm_id = bgm_id + ".mp3"
            self.bgm_check_list.append(bgm_id)

    def add_face_id(self, chat):
        face_id = str(chat["face_id"])
        if face_id and face_id != "0":
            role_id = str(chat["role_id"])
            if role_id not in self.face_check_dir:
                self.face_check_dir[role_id]=[]
            face_id = face_id + ".png"
            self.face_check_dir[role_id].append(face_id)


    def add_role_id(self, chat):
        role_id = str(chat["role_id"])
        if role_id and role_id != "0":
            if role_id not in self.role_fashion_dir:
                self.role_fashion_dir[role_id] = []
        else:
            return
        if "fashion_id" in chat:
            fashion_id = str(chat["fashion_id"])
            if fashion_id and fashion_id != "0":
                self.role_fashion_dir[role_id].append(fashion_id)

    def add_friend_id(self, chat):
        friend_id = None
        if chat["chat_type"] == 8 or chat["chat_type"] ==15 or chat["chat_type"] == 16 or chat["chat_type"] ==19 or chat["chat_type"] ==26 or chat["chat_type"] ==29 or chat["chat_type"] ==30:
            friend_id = str(chat["friend_id"])
            if friend_id and friend_id != "0":
                pass
            else:
                content = "【friend_id资源异常】:对白{}类型为{}的friend_id为空".format(chat["id"],chat["chat_type"])
                mylog.error(content)
                self.error_dir["friend_id"] =content

        if "friend_id" in chat:
            friend_id = str(chat["friend_id"])
            if friend_id and friend_id != "0":
                if friend_id not in self.role_fashion_dir:
                    self.role_fashion_dir[friend_id] = []
            else:
                return
        else:
            print("没有friend_id")
            return
        if "friend_fashion_id" in chat:
            friend_fashion_id = str(chat["friend_fashion_id"])
            if friend_fashion_id and friend_id != "0":
                self.role_fashion_dir[friend_id].append(friend_fashion_id)
        else:
            print("没有friend_fashion_id")

    # def get_selects(self,chat,role_id_list:list):
    #     select

    def getfile_name(self):
        for role_id in self.role_check_dir:
            print(role_id)
            file = self.bookchapter + "/role/" + role_id
            path = os.path.join(path_resource, file)
            print(path)
            self.role_resources_dir[role_id] = []
            for root, dirs, files in os.walk(path):
                self.role_resources_dir[role_id] = self.role_resources_dir[role_id] + files
        self.bg_resources_list = []
        self.bgm_resources_list = []
        self.role_resources_list=[]
        file = self.bookchapter + "/background"
        path = os.path.join(path_resource, file)
        for root, dirs, files in os.walk(path):
            self.bg_resources_list = files
        file = self.bookchapter + "/sound/bgm"
        path = os.path.join(path_resource, file)
        for root, dirs, files in os.walk(path):
            self.bgm_resources_list = files
        # file = self.bookchapter + "/role/" + role_id+"face"
        # path = os.path.join(path_resource, file)
        # for root, dirs, files in os.walk(path):
        #     self.face_resources_list = files

    def getCheckList(self):
        """遍历检测"""
        for self.bookchapter in MyData.check_list:
            self.bookchapter = str(self.bookchapter)
            self.bookid = self.bookchapter[:5]
            self.chapterid = self.bookchapter[5:]
            self.error_dir[self.bookchapter] = {}
            mylog.info("====================================================================================")
            mylog.info("===开始" + self.bookchapter + "资源对比===")
            self.check()
            mylog.info("===完成" + self.bookchapter + "资源对比===")
            # mylog.error("异常列表:{}".format(self.error_dir))
            # print("异常列表：", self.error_dir)
            self.initialize()
            mylog.info("====================================================================================")


if __name__ == '__main__':
    Check1 = Check()
    Check1.getCheckList()
