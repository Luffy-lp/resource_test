#  日志相关的配置
LOGGING = dict(
    level='DEBUG',
    fh_level="DEBUG",
    sh_level="ERROR",
    ih_level="INFO",
    log_name="logging.log",
)